<?php 
// No direct access
defined('_JEXEC') or die; ?>
<?php echo $ciocrsd->quicklist_browse(); ?>
